-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `huvdev` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `huvdev`;

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1,	'Can add log entry',	1,	'add_logentry'),
(2,	'Can change log entry',	1,	'change_logentry'),
(3,	'Can delete log entry',	1,	'delete_logentry'),
(4,	'Can view log entry',	1,	'view_logentry'),
(5,	'Can add permission',	2,	'add_permission'),
(6,	'Can change permission',	2,	'change_permission'),
(7,	'Can delete permission',	2,	'delete_permission'),
(8,	'Can view permission',	2,	'view_permission'),
(9,	'Can add group',	3,	'add_group'),
(10,	'Can change group',	3,	'change_group'),
(11,	'Can delete group',	3,	'delete_group'),
(12,	'Can view group',	3,	'view_group'),
(13,	'Can add user',	4,	'add_user'),
(14,	'Can change user',	4,	'change_user'),
(15,	'Can delete user',	4,	'delete_user'),
(16,	'Can view user',	4,	'view_user'),
(17,	'Can add content type',	5,	'add_contenttype'),
(18,	'Can change content type',	5,	'change_contenttype'),
(19,	'Can delete content type',	5,	'delete_contenttype'),
(20,	'Can view content type',	5,	'view_contenttype'),
(21,	'Can add session',	6,	'add_session'),
(22,	'Can change session',	6,	'change_session'),
(23,	'Can delete session',	6,	'delete_session'),
(24,	'Can view session',	6,	'view_session'),
(25,	'Can add familia',	7,	'add_familia'),
(26,	'Can change familia',	7,	'change_familia'),
(27,	'Can delete familia',	7,	'delete_familia'),
(28,	'Can view familia',	7,	'view_familia'),
(29,	'Can add planta',	8,	'add_planta'),
(30,	'Can change planta',	8,	'change_planta'),
(31,	'Can delete planta',	8,	'delete_planta'),
(32,	'Can view planta',	8,	'view_planta'),
(33,	'Can add epoca',	9,	'add_epoca'),
(34,	'Can change epoca',	9,	'change_epoca'),
(35,	'Can delete epoca',	9,	'delete_epoca'),
(36,	'Can view epoca',	9,	'view_epoca'),
(37,	'Can add fuente',	10,	'add_fuente'),
(38,	'Can change fuente',	10,	'change_fuente'),
(39,	'Can delete fuente',	10,	'delete_fuente'),
(40,	'Can view fuente',	10,	'view_fuente'),
(41,	'Can add sustrato',	11,	'add_sustrato'),
(42,	'Can change sustrato',	11,	'change_sustrato'),
(43,	'Can delete sustrato',	11,	'delete_sustrato'),
(44,	'Can view sustrato',	11,	'view_sustrato'),
(45,	'Can add tipo',	12,	'add_tipo'),
(46,	'Can change tipo',	12,	'change_tipo'),
(47,	'Can delete tipo',	12,	'delete_tipo'),
(48,	'Can view tipo',	12,	'view_tipo'),
(49,	'Can add tip',	13,	'add_tip'),
(50,	'Can change tip',	13,	'change_tip'),
(51,	'Can delete tip',	13,	'delete_tip'),
(52,	'Can view tip',	13,	'view_tip'),
(53,	'Can add rotaciones',	14,	'add_rotaciones'),
(54,	'Can change rotaciones',	14,	'change_rotaciones'),
(55,	'Can delete rotaciones',	14,	'delete_rotaciones'),
(56,	'Can view rotaciones',	14,	'view_rotaciones'),
(57,	'Can add interacciones',	15,	'add_interacciones'),
(58,	'Can change interacciones',	15,	'change_interacciones'),
(59,	'Can delete interacciones',	15,	'delete_interacciones'),
(60,	'Can view interacciones',	15,	'view_interacciones'),
(61,	'Can add ficha',	16,	'add_ficha'),
(62,	'Can change ficha',	16,	'change_ficha'),
(63,	'Can delete ficha',	16,	'delete_ficha'),
(64,	'Can view ficha',	16,	'view_ficha');

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1,	'pbkdf2_sha256$150000$SPOkMJuJ3gwU$oxdhtYHxGiqQwdWnOaJNsiw8HefAOMCtpkHY0YAmtDo=',	'2020-12-06 22:18:12.159666',	1,	'rama',	'',	'',	'ramirohgatti@gmail.com',	1,	1,	'2020-12-06 22:17:15.042058');

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1,	'2020-12-07 03:00:18.670095',	'1',	'Umbelíferas',	1,	'[{\"added\": {}}]',	7,	1),
(2,	'2020-12-07 03:13:20.936046',	'1',	'Zanahoria',	1,	'[{\"added\": {}}]',	8,	1),
(3,	'2020-12-07 03:36:43.986843',	'1',	'Epoca object (1)',	1,	'[{\"added\": {}}]',	9,	1),
(4,	'2020-12-07 03:42:23.361209',	'1',	'Epoca object (1)',	2,	'[]',	9,	1),
(5,	'2020-12-07 03:42:38.502428',	'2',	'Epoca object (2)',	1,	'[{\"added\": {}}]',	9,	1),
(6,	'2020-12-07 03:42:53.432504',	'3',	'Epoca object (3)',	1,	'[{\"added\": {}}]',	9,	1),
(7,	'2020-12-07 03:43:09.089548',	'4',	'Epoca object (4)',	1,	'[{\"added\": {}}]',	9,	1),
(8,	'2020-12-07 03:43:54.527263',	'1',	'Sustrato object (1)',	1,	'[{\"added\": {}}]',	11,	1),
(9,	'2020-12-07 03:44:27.119869',	'1',	'Fuente object (1)',	1,	'[{\"added\": {}}]',	10,	1),
(10,	'2020-12-07 03:44:33.703781',	'1',	'Tip object (1)',	1,	'[{\"added\": {}}]',	13,	1),
(11,	'2020-12-07 03:45:33.553197',	'2',	'Fuente object (2)',	1,	'[{\"added\": {}}]',	10,	1),
(12,	'2020-12-07 03:45:47.462513',	'1',	'Ficha object (1)',	1,	'[{\"added\": {}}]',	16,	1),
(13,	'2020-12-07 03:57:31.202435',	'1',	'Epoca object (1)',	3,	'',	9,	1),
(14,	'2020-12-07 03:58:08.354466',	'1',	'Ficha object (1)',	2,	'[{\"changed\": {\"fields\": [\"epoca_semillero\"]}}]',	16,	1),
(15,	'2020-12-07 04:00:28.833170',	'1',	'Ficha object (1)',	2,	'[]',	16,	1),
(16,	'2020-12-07 04:00:58.533234',	'1',	'Ficha object (1)',	2,	'[]',	16,	1),
(17,	'2020-12-07 04:18:26.047656',	'3',	'Cuidar la tierra',	1,	'[{\"added\": {}}]',	10,	1),
(18,	'2020-12-07 04:20:54.398837',	'1',	'Tip object (1)',	3,	'',	13,	1),
(19,	'2020-12-07 04:21:45.680076',	'1',	'Zanahoria',	3,	'',	16,	1),
(20,	'2020-12-07 04:25:52.609568',	'5',	'Nunca',	1,	'[{\"added\": {}}]',	9,	1),
(21,	'2020-12-07 04:27:08.628322',	'6',	'Anual',	1,	'[{\"added\": {}}]',	9,	1),
(22,	'2020-12-07 04:32:32.279778',	'2',	'Tip object (2)',	1,	'[{\"added\": {}}]',	13,	1),
(23,	'2020-12-07 04:33:19.469455',	'2',	'Suelto',	1,	'[{\"added\": {}}]',	11,	1),
(24,	'2020-12-07 04:33:28.004051',	'2',	'Zanahoria',	1,	'[{\"added\": {}}]',	16,	1),
(25,	'2020-12-07 04:33:41.425035',	'4',	'None',	3,	'',	9,	1),
(26,	'2020-12-07 04:33:41.530827',	'3',	'None',	3,	'',	9,	1),
(27,	'2020-12-07 04:33:41.614368',	'2',	'None',	3,	'',	9,	1),
(28,	'2020-12-07 04:34:06.146993',	'2',	'None',	3,	'',	10,	1),
(29,	'2020-12-07 04:34:06.357017',	'1',	'None',	3,	'',	10,	1),
(30,	'2020-12-07 04:36:21.619314',	'4',	'Mel Bartholomew',	1,	'[{\"added\": {}}]',	10,	1),
(31,	'2020-12-07 04:37:21.656916',	'2',	'Suelto',	3,	'',	11,	1),
(32,	'2020-12-07 04:37:34.933023',	'1',	'Tipo object (1)',	1,	'[{\"added\": {}}]',	12,	1),
(33,	'2020-12-07 04:38:15.054835',	'2',	'FL',	1,	'[{\"added\": {}}]',	12,	1),
(34,	'2020-12-07 04:38:24.101302',	'3',	'HO',	1,	'[{\"added\": {}}]',	12,	1),
(35,	'2020-12-07 04:38:32.374214',	'4',	'RA',	1,	'[{\"added\": {}}]',	12,	1),
(36,	'2020-12-07 04:45:06.834792',	'2',	'Cosecha',	2,	'[{\"changed\": {\"fields\": [\"descripcion\", \"contenido\", \"fuente\"]}}]',	13,	1),
(37,	'2020-12-07 04:47:26.337649',	'1',	'Interacciones object (1)',	1,	'[{\"added\": {}}]',	15,	1),
(38,	'2020-12-07 04:57:50.917773',	'2',	'Compuesta',	1,	'[{\"added\": {}}]',	7,	1),
(39,	'2020-12-07 04:57:54.924246',	'2',	'Lechuga',	1,	'[{\"added\": {}}]',	8,	1),
(40,	'2020-12-07 05:21:17.350105',	'1',	'Zanahoria',	2,	'[]',	15,	1),
(41,	'2020-12-07 05:31:57.161138',	'1',	'Zanahoria',	2,	'[]',	15,	1),
(42,	'2020-12-07 05:33:39.811555',	'1',	'Rotaciones object (1)',	1,	'[{\"added\": {}}]',	14,	1),
(43,	'2020-12-07 05:37:45.764292',	'3',	'Crucíferas',	1,	'[{\"added\": {}}]',	7,	1),
(44,	'2020-12-07 05:39:27.381672',	'1',	'None',	3,	'',	14,	1),
(45,	'2020-12-07 05:39:36.862305',	'3',	'None',	1,	'[{\"added\": {}}]',	14,	1),
(46,	'2020-12-07 05:44:37.953711',	'4',	'Solanáceas',	1,	'[{\"added\": {}}]',	7,	1),
(47,	'2020-12-07 05:44:46.408106',	'4',	'Umbelíferas',	1,	'[{\"added\": {}}]',	14,	1),
(48,	'2020-12-07 05:48:56.432941',	'5',	'Cucurbitáceas',	1,	'[{\"added\": {}}]',	7,	1),
(49,	'2020-12-07 05:49:03.170488',	'5',	'Compuesta',	1,	'[{\"added\": {}}]',	14,	1),
(50,	'2020-12-07 05:49:38.329268',	'3',	'Compuesta',	2,	'[{\"changed\": {\"fields\": [\"anterior\"]}}]',	14,	1),
(51,	'2020-12-07 05:49:55.440923',	'5',	'Crucíferas',	2,	'[{\"changed\": {\"fields\": [\"anterior\", \"actual\", \"posterior\"]}}]',	14,	1),
(52,	'2020-12-07 05:51:20.962194',	'6',	'Gramíneas',	1,	'[{\"added\": {}}]',	7,	1),
(53,	'2020-12-07 05:51:34.014964',	'6',	'Solanáceas',	1,	'[{\"added\": {}}]',	14,	1),
(54,	'2020-12-07 05:52:39.216548',	'7',	'Leguminosas',	1,	'[{\"added\": {}}]',	7,	1),
(55,	'2020-12-07 05:52:44.219094',	'7',	'Gramíneas',	1,	'[{\"added\": {}}]',	14,	1),
(56,	'2020-12-07 05:53:40.827819',	'8',	'Quenopoidáceas',	1,	'[{\"added\": {}}]',	7,	1),
(57,	'2020-12-07 05:53:47.745901',	'8',	'Leguminosas',	1,	'[{\"added\": {}}]',	14,	1),
(58,	'2020-12-07 05:54:54.718913',	'9',	'Alliáceas',	1,	'[{\"added\": {}}]',	7,	1),
(59,	'2020-12-07 05:55:56.264350',	'9',	'Quenopoidáceas',	1,	'[{\"added\": {}}]',	14,	1),
(60,	'2020-12-07 05:56:22.759937',	'10',	'Alliáceas',	1,	'[{\"added\": {}}]',	14,	1),
(61,	'2020-12-08 03:40:01.337019',	'3',	'Acelga',	1,	'[{\"added\": {}}]',	8,	1),
(62,	'2020-12-08 03:46:14.775105',	'10',	'Labiadas',	1,	'[{\"added\": {}}]',	7,	1),
(63,	'2020-12-08 03:46:27.437526',	'4',	'Albahaca',	1,	'[{\"added\": {}}]',	8,	1),
(64,	'2020-12-08 03:49:01.457329',	'5',	'Ajo',	1,	'[{\"added\": {}}]',	8,	1),
(65,	'2020-12-08 03:52:08.928783',	'6',	'Apio',	1,	'[{\"added\": {}}]',	8,	1),
(66,	'2020-12-08 03:54:30.574319',	'7',	'Arveja',	1,	'[{\"added\": {}}]',	8,	1),
(67,	'2020-12-08 03:56:17.676505',	'8',	'Berenjena',	1,	'[{\"added\": {}}]',	8,	1),
(68,	'2020-12-08 03:56:53.318275',	'9',	'Brócoli',	1,	'[{\"added\": {}}]',	8,	1),
(69,	'2020-12-08 03:57:20.590674',	'10',	'Coliflor',	1,	'[{\"added\": {}}]',	8,	1),
(70,	'2020-12-08 03:57:53.820555',	'11',	'Cebolla',	1,	'[{\"added\": {}}]',	8,	1),
(71,	'2020-12-08 03:58:18.658735',	'12',	'Cebolla de verdeo',	1,	'[{\"added\": {}}]',	8,	1),
(72,	'2020-12-08 03:58:50.028075',	'13',	'Chaucha',	1,	'[{\"added\": {}}]',	8,	1),
(73,	'2020-12-08 03:59:23.487047',	'14',	'Choclo',	1,	'[{\"added\": {}}]',	8,	1),
(74,	'2020-12-08 04:00:05.948193',	'15',	'Espárrago',	1,	'[{\"added\": {}}]',	8,	1),
(75,	'2020-12-08 04:00:19.875699',	'16',	'Espinaca',	1,	'[{\"added\": {}}]',	8,	1),
(76,	'2020-12-08 04:02:57.840988',	'11',	'Rosáceas',	1,	'[{\"added\": {}}]',	7,	1),
(77,	'2020-12-08 04:03:04.241761',	'17',	'Frutilla',	1,	'[{\"added\": {}}]',	8,	1),
(78,	'2020-12-08 04:03:17.216109',	'18',	'Haba',	1,	'[{\"added\": {}}]',	8,	1),
(79,	'2020-12-08 04:04:11.407078',	'19',	'Hinojo',	1,	'[{\"added\": {}}]',	8,	1),
(80,	'2020-12-08 04:04:25.079739',	'20',	'Lechuga',	1,	'[{\"added\": {}}]',	8,	1),
(81,	'2020-12-08 04:04:45.928698',	'21',	'Escarola',	1,	'[{\"added\": {}}]',	8,	1),
(82,	'2020-12-08 04:05:03.541353',	'22',	'Melón',	1,	'[{\"added\": {}}]',	8,	1),
(83,	'2020-12-08 04:05:41.559544',	'23',	'Sandía',	1,	'[{\"added\": {}}]',	8,	1),
(84,	'2020-12-08 04:05:59.492247',	'24',	'Papa',	1,	'[{\"added\": {}}]',	8,	1),
(85,	'2020-12-08 04:06:16.706803',	'25',	'Pepino',	1,	'[{\"added\": {}}]',	8,	1),
(86,	'2020-12-08 04:07:20.835582',	'26',	'Perejil',	1,	'[{\"added\": {}}]',	8,	1),
(87,	'2020-12-08 04:07:43.338246',	'27',	'Pimiento',	1,	'[{\"added\": {}}]',	8,	1),
(88,	'2020-12-08 04:08:14.476249',	'28',	'Puerro',	1,	'[{\"added\": {}}]',	8,	1),
(89,	'2020-12-08 04:08:57.993011',	'29',	'Rabanito',	1,	'[{\"added\": {}}]',	8,	1),
(90,	'2020-12-08 04:09:12.855456',	'30',	'Radicheta',	1,	'[{\"added\": {}}]',	8,	1),
(91,	'2020-12-08 04:09:36.062017',	'31',	'Remolacha',	1,	'[{\"added\": {}}]',	8,	1),
(92,	'2020-12-08 04:09:55.493199',	'32',	'Repollo',	1,	'[{\"added\": {}}]',	8,	1),
(93,	'2020-12-08 04:10:04.978199',	'33',	'Rúcula',	1,	'[{\"added\": {}}]',	8,	1),
(94,	'2020-12-08 04:10:20.360793',	'34',	'Tomate',	1,	'[{\"added\": {}}]',	8,	1),
(95,	'2020-12-08 04:11:28.393192',	'20',	'Lechuga',	3,	'',	8,	1),
(96,	'2020-12-08 04:12:20.152181',	'35',	'Zapallo',	1,	'[{\"added\": {}}]',	8,	1),
(97,	'2020-12-08 04:12:44.028160',	'36',	'Cayote',	1,	'[{\"added\": {}}]',	8,	1),
(98,	'2020-12-08 04:13:22.937686',	'37',	'Zapallito',	1,	'[{\"added\": {}}]',	8,	1),
(99,	'2020-12-08 04:13:48.745125',	'38',	'Zuccini',	1,	'[{\"added\": {}}]',	8,	1),
(100,	'2020-12-08 04:18:41.434054',	'5',	'INTA',	1,	'[{\"added\": {}}]',	10,	1),
(101,	'2020-12-08 04:20:42.011640',	'3',	'Cosecha semilla',	1,	'[{\"added\": {}}]',	13,	1),
(102,	'2020-12-08 04:23:10.639364',	'3',	'Cosecha semilla acelga',	2,	'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',	13,	1),
(103,	'2020-12-08 04:23:36.426168',	'2',	'Cosecha raíces',	2,	'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',	13,	1),
(104,	'2020-12-08 04:23:44.189217',	'2',	'Cosecha raíces',	2,	'[]',	13,	1),
(105,	'2020-12-08 04:34:53.533966',	'6',	'SI de ENE a DIC',	2,	'[{\"changed\": {\"fields\": [\"desde\", \"hasta\"]}}]',	9,	1),
(106,	'2020-12-08 04:35:02.138908',	'5',	'SE de ENE a DIC',	2,	'[{\"changed\": {\"fields\": [\"desde\", \"hasta\"]}}]',	9,	1),
(107,	'2020-12-08 04:37:58.381989',	'5',	'SE de ENE a ENE',	2,	'[{\"changed\": {\"fields\": [\"hasta\"]}}]',	9,	1),
(108,	'2020-12-08 04:39:18.184647',	'2',	'Zanahoria',	2,	'[{\"changed\": {\"fields\": [\"epoca_trasplante\", \"sustrato\", \"fuentes\"]}}]',	16,	1);

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1,	'admin',	'logentry'),
(3,	'auth',	'group'),
(2,	'auth',	'permission'),
(4,	'auth',	'user'),
(5,	'contenttypes',	'contenttype'),
(9,	'plantas',	'epoca'),
(7,	'plantas',	'familia'),
(16,	'plantas',	'ficha'),
(10,	'plantas',	'fuente'),
(15,	'plantas',	'interacciones'),
(8,	'plantas',	'planta'),
(14,	'plantas',	'rotaciones'),
(11,	'plantas',	'sustrato'),
(13,	'plantas',	'tip'),
(12,	'plantas',	'tipo'),
(6,	'sessions',	'session');

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1,	'contenttypes',	'0001_initial',	'2020-12-06 22:12:28.532954'),
(2,	'auth',	'0001_initial',	'2020-12-06 22:12:32.000658'),
(3,	'admin',	'0001_initial',	'2020-12-06 22:12:45.644412'),
(4,	'admin',	'0002_logentry_remove_auto_add',	'2020-12-06 22:12:48.676176'),
(5,	'admin',	'0003_logentry_add_action_flag_choices',	'2020-12-06 22:12:48.778629'),
(6,	'contenttypes',	'0002_remove_content_type_name',	'2020-12-06 22:12:51.413138'),
(7,	'auth',	'0002_alter_permission_name_max_length',	'2020-12-06 22:12:52.879960'),
(8,	'auth',	'0003_alter_user_email_max_length',	'2020-12-06 22:12:53.199174'),
(9,	'auth',	'0004_alter_user_username_opts',	'2020-12-06 22:12:53.299240'),
(10,	'auth',	'0005_alter_user_last_login_null',	'2020-12-06 22:12:54.581280'),
(11,	'auth',	'0006_require_contenttypes_0002',	'2020-12-06 22:12:54.693376'),
(12,	'auth',	'0007_alter_validators_add_error_messages',	'2020-12-06 22:12:54.796780'),
(13,	'auth',	'0008_alter_user_username_max_length',	'2020-12-06 22:12:57.380695'),
(14,	'auth',	'0009_alter_user_last_name_max_length',	'2020-12-06 22:12:59.062109'),
(15,	'auth',	'0010_alter_group_name_max_length',	'2020-12-06 22:12:59.372111'),
(16,	'auth',	'0011_update_proxy_permissions',	'2020-12-06 22:12:59.604766'),
(17,	'plantas',	'0001_initial',	'2020-12-06 22:13:00.965368'),
(18,	'plantas',	'0002_auto_20201206_2153',	'2020-12-06 22:13:11.874667'),
(19,	'sessions',	'0001_initial',	'2020-12-06 22:13:45.292939'),
(20,	'plantas',	'0003_planta_especie',	'2020-12-07 03:08:13.165099'),
(21,	'plantas',	'0004_auto_20201207_0356',	'2020-12-07 03:56:36.066068'),
(22,	'plantas',	'0005_auto_20201207_0358',	'2020-12-07 03:58:37.554472'),
(23,	'plantas',	'0006_auto_20201207_0410',	'2020-12-07 04:10:46.677617'),
(24,	'plantas',	'0007_epoca_estacion',	'2020-12-07 04:24:43.217649'),
(25,	'plantas',	'0008_tip_descripcion',	'2020-12-07 04:44:30.616587'),
(26,	'plantas',	'0009_rotaciones_actual',	'2020-12-07 05:38:41.075613'),
(27,	'plantas',	'0010_auto_20201208_0258',	'2020-12-08 02:59:00.256193'),
(28,	'plantas',	'0011_auto_20201208_0331',	'2020-12-08 03:31:46.489907'),
(29,	'plantas',	'0012_auto_20201208_0335',	'2020-12-08 03:35:11.226443');

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('2ti7zrwb16hhjxtxyrvzdkwarbjersjm',	'ZGJjZjhmYWEyMTUwYTllMjVjMTNlMzhiNmE0NDRhNmI3OGViMzY1ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJhNDZkNjE0MzRiMGJkZjYwMTBlNTg5NjU3NzYwM2JmMjIzNjBmNmU0In0=',	'2020-12-20 22:18:12.331600');

DROP TABLE IF EXISTS `plantas_epoca`;
CREATE TABLE `plantas_epoca` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(200) NOT NULL,
  `desde` varchar(200) NOT NULL,
  `hasta` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_epoca` (`id`, `tipo`, `desde`, `hasta`) VALUES
(5,	'SE',	'ENE',	'ENE'),
(6,	'SI',	'ENE',	'DIC');

DROP TABLE IF EXISTS `plantas_familia`;
CREATE TABLE `plantas_familia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) DEFAULT NULL,
  `nombre_cientifico` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_familia` (`id`, `nombre_popular`, `nombre_cientifico`) VALUES
(1,	'Umbelíferas',	'Apiaceae'),
(2,	'Compuesta',	'Asteraceae'),
(3,	'Crucíferas',	'Brassicaceae'),
(4,	'Solanáceas',	'Solanaceae'),
(5,	'Cucurbitáceas',	'Cucurbitaceae'),
(6,	'Gramíneas',	'Poaceae'),
(7,	'Leguminosas',	'Fabaceae'),
(8,	'Quenopoidáceas',	'Chenopodioideae'),
(9,	'Alliáceas',	'Allioideae'),
(10,	'Labiadas',	'Lamiaceae'),
(11,	'Rosáceas',	'Rosaceae');

DROP TABLE IF EXISTS `plantas_ficha`;
CREATE TABLE `plantas_ficha` (
  `id` int NOT NULL AUTO_INCREMENT,
  `volumen_mazeta_ltr` decimal(5,2) NOT NULL,
  `profundidad` decimal(5,2) NOT NULL,
  `tamano` varchar(200) NOT NULL,
  `distancia` decimal(5,2) NOT NULL,
  `temperatura` decimal(5,2) NOT NULL,
  `horas_sol` decimal(5,2) NOT NULL,
  `riego` varchar(200) NOT NULL,
  `tiempo_cultivo_dias` int NOT NULL,
  `tutorado` tinyint(1) NOT NULL,
  `epoca_cosecha_id` int DEFAULT NULL,
  `epoca_semillero_id` int DEFAULT NULL,
  `epoca_siembra_id` int DEFAULT NULL,
  `epoca_trasplante_id` int DEFAULT NULL,
  `planta_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_ficha_epoca_cosecha_id_02a1116a_fk_plantas_epoca_id` (`epoca_cosecha_id`),
  KEY `plantas_ficha_epoca_semillero_id_469d5fbf_fk_plantas_epoca_id` (`epoca_semillero_id`),
  KEY `plantas_ficha_epoca_siembra_id_0b619923_fk_plantas_epoca_id` (`epoca_siembra_id`),
  KEY `plantas_ficha_epoca_trasplante_id_5dd2c916_fk_plantas_epoca_id` (`epoca_trasplante_id`),
  KEY `plantas_ficha_planta_id_77990985_fk_plantas_planta_id` (`planta_id`),
  CONSTRAINT `plantas_ficha_epoca_cosecha_id_02a1116a_fk_plantas_epoca_id` FOREIGN KEY (`epoca_cosecha_id`) REFERENCES `plantas_epoca` (`id`),
  CONSTRAINT `plantas_ficha_epoca_semillero_id_469d5fbf_fk_plantas_epoca_id` FOREIGN KEY (`epoca_semillero_id`) REFERENCES `plantas_epoca` (`id`),
  CONSTRAINT `plantas_ficha_epoca_siembra_id_0b619923_fk_plantas_epoca_id` FOREIGN KEY (`epoca_siembra_id`) REFERENCES `plantas_epoca` (`id`),
  CONSTRAINT `plantas_ficha_epoca_trasplante_id_5dd2c916_fk_plantas_epoca_id` FOREIGN KEY (`epoca_trasplante_id`) REFERENCES `plantas_epoca` (`id`),
  CONSTRAINT `plantas_ficha_planta_id_77990985_fk_plantas_planta_id` FOREIGN KEY (`planta_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha` (`id`, `volumen_mazeta_ltr`, `profundidad`, `tamano`, `distancia`, `temperatura`, `horas_sol`, `riego`, `tiempo_cultivo_dias`, `tutorado`, `epoca_cosecha_id`, `epoca_semillero_id`, `epoca_siembra_id`, `epoca_trasplante_id`, `planta_id`) VALUES
(2,	1.70,	25.00,	'S',	7.50,	20.00,	6.00,	'1xD',	10,	0,	6,	5,	6,	5,	1);

DROP TABLE IF EXISTS `plantas_ficha_fuentes`;
CREATE TABLE `plantas_ficha_fuentes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `fuente_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_fuentes_ficha_id_fuente_id_8dd8987e_uniq` (`ficha_id`,`fuente_id`),
  KEY `plantas_ficha_fuentes_fuente_id_23132f93_fk_plantas_fuente_id` (`fuente_id`),
  CONSTRAINT `plantas_ficha_fuentes_ficha_id_2600f209_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`),
  CONSTRAINT `plantas_ficha_fuentes_fuente_id_23132f93_fk_plantas_fuente_id` FOREIGN KEY (`fuente_id`) REFERENCES `plantas_fuente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_fuentes` (`id`, `ficha_id`, `fuente_id`) VALUES
(3,	2,	5);

DROP TABLE IF EXISTS `plantas_ficha_sustrato`;
CREATE TABLE `plantas_ficha_sustrato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `sustrato_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_sustrato_ficha_id_sustrato_id_f2609d69_uniq` (`ficha_id`,`sustrato_id`),
  KEY `plantas_ficha_sustra_sustrato_id_4aedc587_fk_plantas_s` (`sustrato_id`),
  CONSTRAINT `plantas_ficha_sustra_sustrato_id_4aedc587_fk_plantas_s` FOREIGN KEY (`sustrato_id`) REFERENCES `plantas_sustrato` (`id`),
  CONSTRAINT `plantas_ficha_sustrato_ficha_id_aea9e53b_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_sustrato` (`id`, `ficha_id`, `sustrato_id`) VALUES
(3,	2,	1);

DROP TABLE IF EXISTS `plantas_ficha_tips`;
CREATE TABLE `plantas_ficha_tips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ficha_id` int NOT NULL,
  `tip_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_ficha_tips_ficha_id_tip_id_2156d431_uniq` (`ficha_id`,`tip_id`),
  KEY `plantas_ficha_tips_tip_id_96bbadf3_fk_plantas_tip_id` (`tip_id`),
  CONSTRAINT `plantas_ficha_tips_ficha_id_a6e5af8e_fk_plantas_ficha_id` FOREIGN KEY (`ficha_id`) REFERENCES `plantas_ficha` (`id`),
  CONSTRAINT `plantas_ficha_tips_tip_id_96bbadf3_fk_plantas_tip_id` FOREIGN KEY (`tip_id`) REFERENCES `plantas_tip` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_ficha_tips` (`id`, `ficha_id`, `tip_id`) VALUES
(2,	2,	2);

DROP TABLE IF EXISTS `plantas_fuente`;
CREATE TABLE `plantas_fuente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cita` longtext NOT NULL,
  `autor` varchar(200) DEFAULT NULL,
  `url` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_fuente` (`id`, `cita`, `autor`, `url`) VALUES
(3,	'Ficha zanahoria',	'Cuidar la tierra',	'https://www.instagram.com/p/CGsVlzQDvuO/'),
(4,	'All new square foot gardening',	'Mel Bartholomew',	'None'),
(5,	'INTA',	'INTA',	'INTA');

DROP TABLE IF EXISTS `plantas_interacciones`;
CREATE TABLE `plantas_interacciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(200) NOT NULL,
  `target_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_interacciones_target_id_29d24dc1_fk_plantas_planta_id` (`target_id`),
  CONSTRAINT `plantas_interacciones_target_id_29d24dc1_fk_plantas_planta_id` FOREIGN KEY (`target_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_interacciones` (`id`, `tipo`, `target_id`) VALUES
(1,	'B',	1);

DROP TABLE IF EXISTS `plantas_interacciones_actores`;
CREATE TABLE `plantas_interacciones_actores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `interacciones_id` int NOT NULL,
  `planta_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plantas_interacciones_ac_interacciones_id_planta__0d8ca849_uniq` (`interacciones_id`,`planta_id`),
  KEY `plantas_interaccione_planta_id_ed75f566_fk_plantas_p` (`planta_id`),
  CONSTRAINT `plantas_interaccione_interacciones_id_61cb0655_fk_plantas_i` FOREIGN KEY (`interacciones_id`) REFERENCES `plantas_interacciones` (`id`),
  CONSTRAINT `plantas_interaccione_planta_id_ed75f566_fk_plantas_p` FOREIGN KEY (`planta_id`) REFERENCES `plantas_planta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_interacciones_actores` (`id`, `interacciones_id`, `planta_id`) VALUES
(1,	1,	1);

DROP TABLE IF EXISTS `plantas_planta`;
CREATE TABLE `plantas_planta` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre_popular` varchar(200) DEFAULT NULL,
  `nombre_cientifico` varchar(200) DEFAULT NULL,
  `familia_id` int DEFAULT NULL,
  `variedad` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_planta_familia_id_77279843_fk_plantas_familia_id` (`familia_id`),
  CONSTRAINT `plantas_planta_familia_id_77279843_fk_plantas_familia_id` FOREIGN KEY (`familia_id`) REFERENCES `plantas_familia` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_planta` (`id`, `nombre_popular`, `nombre_cientifico`, `familia_id`, `variedad`) VALUES
(1,	'Zanahoria',	'Daucus carota',	1,	'Sativus'),
(2,	'Lechuga',	'Lactuca',	2,	'Sativa'),
(3,	'Acelga',	'Beta vulgaris',	8,	'Cicla'),
(4,	'Albahaca',	'Ocimum basilicum',	10,	'Cicla'),
(5,	'Ajo',	'Allium sativun',	9,	'sativa'),
(6,	'Apio',	'Apium graveolens',	1,	'Común'),
(7,	'Arveja',	'Pisum sativum',	7,	'sativum'),
(8,	'Berenjena',	'Berenjena',	4,	'Berenjena'),
(9,	'Brócoli',	'Brócoli',	3,	'Brócoli'),
(10,	'Coliflor',	'Coliflor',	3,	'Coliflor'),
(11,	'Cebolla',	'Cebolla',	9,	'Cebolla'),
(12,	'Cebolla de verdeo',	'Cebolla de verdeo',	9,	'Cebolla de verdeo'),
(13,	'Chaucha',	'Chaucha',	7,	'Chaucha'),
(14,	'Choclo',	'Choclo',	6,	'Choclo'),
(15,	'Espárrago',	'Espárrago',	9,	'Espárrago'),
(16,	'Espinaca',	'Espinaca',	8,	'Espinaca'),
(17,	'Frutilla',	'Fragaria',	11,	'Frutilla'),
(18,	'Haba',	'Haba',	7,	'Haba'),
(19,	'Hinojo',	'Hinojo',	1,	'Hinojo'),
(21,	'Escarola',	'Escarola',	2,	'Escarola'),
(22,	'Melón',	'Melón',	5,	'Melón'),
(23,	'Sandía',	'Sandía',	5,	'Sandía'),
(24,	'Papa',	'Papa',	4,	'Papa'),
(25,	'Pepino',	'Pepino',	5,	'Pepino'),
(26,	'Perejil',	'Perejil',	1,	'Perejil'),
(27,	'Pimiento',	'Pimiento',	4,	'Pimiento'),
(28,	'Puerro',	'Puerro',	9,	'Puerro'),
(29,	'Rabanito',	'Rabanito',	3,	'Rabanito'),
(30,	'Radicheta',	'Radicheta',	2,	'Radicheta'),
(31,	'Remolacha',	'Remolacha',	8,	'Remolacha'),
(32,	'Repollo',	'Repollo',	3,	'Repollo'),
(33,	'Rúcula',	'Rúcula',	3,	'Rúcula'),
(34,	'Tomate',	'Tomate',	4,	'Tomate'),
(35,	'Zapallo',	'Zapallo',	5,	'Zapallo'),
(36,	'Cayote',	'Cayote',	5,	'Cayote'),
(37,	'Zapallito',	'Zapallito',	5,	'Zapallito'),
(38,	'Zuccini',	'Zuccini',	5,	'Zuccini');

DROP TABLE IF EXISTS `plantas_rotaciones`;
CREATE TABLE `plantas_rotaciones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `anterior_id` int DEFAULT NULL,
  `posterior_id` int DEFAULT NULL,
  `actual_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` (`anterior_id`),
  KEY `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` (`posterior_id`),
  KEY `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` (`actual_id`),
  CONSTRAINT `plantas_rotaciones_actual_id_d25be4a3_fk_plantas_familia_id` FOREIGN KEY (`actual_id`) REFERENCES `plantas_familia` (`id`),
  CONSTRAINT `plantas_rotaciones_anterior_id_f8637944_fk_plantas_familia_id` FOREIGN KEY (`anterior_id`) REFERENCES `plantas_familia` (`id`),
  CONSTRAINT `plantas_rotaciones_posterior_id_93dca290_fk_plantas_familia_id` FOREIGN KEY (`posterior_id`) REFERENCES `plantas_familia` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_rotaciones` (`id`, `anterior_id`, `posterior_id`, `actual_id`) VALUES
(3,	5,	3,	2),
(4,	3,	4,	1),
(5,	2,	1,	3),
(6,	1,	6,	4),
(7,	4,	7,	6),
(8,	6,	8,	7),
(9,	7,	9,	8),
(10,	8,	5,	9);

DROP TABLE IF EXISTS `plantas_sustrato`;
CREATE TABLE `plantas_sustrato` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tierra` varchar(200) DEFAULT NULL,
  `potasio` tinyint(1) NOT NULL,
  `nitrogeno` tinyint(1) NOT NULL,
  `fosforo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_sustrato` (`id`, `tierra`, `potasio`, `nitrogeno`, `fosforo`) VALUES
(1,	'Suelto',	0,	0,	0);

DROP TABLE IF EXISTS `plantas_tip`;
CREATE TABLE `plantas_tip` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contenido` longtext NOT NULL,
  `fuente_id` int DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `plantas_tip_fuente_id_6c2d03a8_fk_plantas_fuente_id` (`fuente_id`),
  CONSTRAINT `plantas_tip_fuente_id_6c2d03a8_fk_plantas_fuente_id` FOREIGN KEY (`fuente_id`) REFERENCES `plantas_fuente` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_tip` (`id`, `contenido`, `fuente_id`, `descripcion`) VALUES
(2,	'Cuando asome de la tierra',	4,	'Cosecha raíces'),
(3,	'Corte de tallos florales que se van secando',	5,	'Cosecha semilla acelga');

DROP TABLE IF EXISTS `plantas_tipo`;
CREATE TABLE `plantas_tipo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `plantas_tipo` (`id`, `nombre`) VALUES
(1,	'FR'),
(2,	'FL'),
(3,	'HO'),
(4,	'RA');

-- 2020-12-08 04:39:42
